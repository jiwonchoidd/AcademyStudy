1 - fps, timer
f2 - wireframe