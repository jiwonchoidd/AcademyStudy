#pragma once
#include <windows.h>
class TSound
{
};

