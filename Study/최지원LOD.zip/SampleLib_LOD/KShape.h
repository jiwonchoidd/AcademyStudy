#pragma once
#include "KModel.h"
class KShape : public KModel
{
};
class KBoxShape : public KShape
{
};
