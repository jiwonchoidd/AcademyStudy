#include "KMap.h"
bool    KMap::Load(KMapInfo& info)
{
    m_info = info;
    m_info.m_iNumColCell = m_info.m_iNumCol - 1;
    m_info.m_iNumRowCell = m_info.m_iNumRow - 1;
    m_info.m_iNumVertex = m_info.m_iNumCol * m_info.m_iNumRow;
    return true;
}
bool	KMap::CreateVertexData()
{
    m_pVertexList.resize(m_info.m_iNumVertex);

    int iIndex = 0;
    for (int iRow=0; iRow < m_info.m_iNumRow; iRow++)
    {
        for (int iCol = 0; iCol < m_info.m_iNumCol; iCol++)
        {
            int iIndex = iRow * m_info.m_iNumRow + iCol;
            m_pVertexList[iIndex].pos.x = m_info.m_fCellDistance * iCol;
            m_pVertexList[iIndex].pos.y = 0.0f;
            m_pVertexList[iIndex].pos.z = -m_info.m_fCellDistance * iRow;
            m_pVertexList[iIndex].color = 
                KVector4(
                    randstep(0.0f, 1.0f),
                    randstep(0.0f, 1.0f),
                    randstep(0.0f, 1.0f),1.0f);            
        }
    }
    if (m_pVertexList.size() > 0) return true;
    return false;
}
bool	KMap::CreateIndexData()
{

    m_IndexList.resize(m_info.m_iNumColCell * m_info.m_iNumRowCell * 2 * 3);

    int iIndex = 0;
    for (int iRow = 0; iRow < m_info.m_iNumRowCell; iRow++)
    {
        for (int iCol = 0; iCol < m_info.m_iNumColCell; iCol++)
        {
            int iCurrentIndex = iRow * m_info.m_iNumRow + iCol;
            int iNextRow = (iRow+1) * m_info.m_iNumRow + iCol;
            m_IndexList[iIndex+0] = iCurrentIndex;
            m_IndexList[iIndex+1] = iCurrentIndex+1;
            m_IndexList[iIndex+2] = iNextRow;

            m_IndexList[iIndex+3] = m_IndexList[iIndex + 2];
            m_IndexList[iIndex+4] = m_IndexList[iIndex + 1];
            m_IndexList[iIndex+5] = iNextRow + 1;
            iIndex += 6;
        }
    }
    if (m_IndexList.size() > 0) return true;
    return false;
}
